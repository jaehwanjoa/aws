import os
import json
import boto3
import logging
from typing import Any, Dict

logger = logging.getLogger()
logger.setLevel(logging.INFO)

# ===============================
# AssumeRole 설정 (B 계정)
# ===============================
TARGET_ROLE_ARN = os.environ.get("TARGET_ROLE_ARN")
REGION = os.environ.get("TARGET_REGION")

sts = boto3.client("sts")

def get_sechub_client():
    resp = sts.assume_role(
        RoleArn=TARGET_ROLE_ARN,
        RoleSessionName="SecurityHubAutomation"
    )

    creds = resp["Credentials"]

    return boto3.client(
        "securityhub",
        aws_access_key_id=creds["AccessKeyId"],
        aws_secret_access_key=creds["SecretAccessKey"],
        aws_session_token=creds["SessionToken"],
        region_name=REGION
    )

NOTE_RESOLVED = "보안 운영자가 1차 검토 완료: 이슈 없음 종료."
NOTE_SUPPRESSED = "보안 운영자가 1차 검토 완료: 일시적 예외처리"

def lambda_handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    # ===============================
    # 1. SNS unwrap
    # ===============================
    if "Records" in event and event["Records"][0].get("EventSource") == "aws:sns":
        event = json.loads(event["Records"][0]["Sns"]["Message"])

    detail_type = event.get("detail-type")
    findings = event.get("detail", {}).get("findings", [])

    logger.info(f"DetailType={detail_type}, Findings={len(findings)}")

    # 🔑 AssumeRole 후 Security Hub client
    sechub = get_sechub_client()

    for f in findings:
        finding_id = f.get("Id")
        product_arn = f.get("ProductArn")

        # ===============================
        # ✅ Custom Action → Workflow 변경
        # ===============================
        if detail_type == "Security Hub Findings - Custom Action":
            logger.info(f"Custom Action detected | id={finding_id}")

            try:
                sechub.batch_update_findings(
                    FindingIdentifiers=[
                        {
                            "Id": finding_id,
                            "ProductArn": product_arn
                        }
                    ],
                    Workflow={
                        "Status": "NOTIFIED"
                    }
                )
                logger.info(f"Workflow updated to NOTIFIED | id={finding_id}")
            except Exception:
                logger.exception(f"Workflow update failed | id={finding_id}")

            # Custom Action은 노트 처리 안 함
            continue

        # ===============================
        # 기존 노트 자동화 로직
        # ===============================
        workflow = f.get("Workflow", {}).get("Status")
        note = f.get("Note", {})

        if note.get("Text", "").strip():
            logger.info(f"Skip (note exists) | id={finding_id}")
            continue

        if workflow == "RESOLVED":
            note_text = NOTE_RESOLVED
        elif workflow == "SUPPRESSED":
            note_text = NOTE_SUPPRESSED
        else:
            logger.info(f"Skip (unsupported workflow={workflow}) | id={finding_id}")
            continue

        logger.info(f"Adding note | workflow={workflow} | id={finding_id}")

        try:
            sechub.batch_update_findings(
                FindingIdentifiers=[
                    {
                        "Id": finding_id,
                        "ProductArn": product_arn
                    }
                ],
                Note={
                    "Text": note_text,
                    "UpdatedBy": "SecurityHub-Automation"
                }
            )
        except Exception:
            logger.exception(f"BatchUpdateFindings failed | id={finding_id}")

    return {
        "statusCode": 200,
        "body": "Automation completed"
    }
