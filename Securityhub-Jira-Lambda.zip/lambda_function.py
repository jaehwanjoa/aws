import json
import os
import urllib.request
import urllib.error
from datetime import datetime, timedelta
from typing import Dict, Any, List


def convert_kst(utc_time: str) -> str:
    """UTC 문자열을 KST로 변환"""
    if not utc_time:
        return "N/A"
    for fmt in ("%Y-%m-%dT%H:%M:%S.%fZ", "%Y-%m-%dT%H:%M:%SZ"):
        try:
            utc = datetime.strptime(utc_time, fmt)
            return (utc + timedelta(hours=9)).strftime("%Y-%m-%d %H:%M:%S")
        except ValueError:
            continue
    return utc_time or "N/A"


# -----------------------------
# Jira Automation Webhook
# -----------------------------
def post_to_jira(payload: Dict[str, Any]) -> None:
    """Jira Automation Webhook으로 전송"""
    webhook_url = (os.environ.get("JIRA_WEBHOOK_URL") or "").strip()
    secret = (os.environ.get("JIRA_AUTOMATION_TOKEN") or "").strip()

    if not webhook_url or not secret:
        raise RuntimeError("환경변수 JIRA_WEBHOOK_URL 또는 JIRA_AUTOMATION_TOKEN이 없습니다.")

    headers = {
        "Content-Type": "application/json",
        "X-Automation-Webhook-Token": secret,
    }

    req = urllib.request.Request(
        webhook_url,
        data=json.dumps(payload, ensure_ascii=False).encode("utf-8"),
        headers=headers,
        method="POST",
    )

    try:
        with urllib.request.urlopen(req, timeout=10) as response:
            body = response.read().decode()
            print("Jira Response:", body[:1000])
    except urllib.error.HTTPError as e:
        print(f"Jira HTTPError: {e.code} {e.reason}")
        try:
            print((e.read() or b"").decode()[:1000])
        except Exception:
            pass
        raise
    except urllib.error.URLError as e:
        print(f"Jira URLError: {e.reason}")
        raise


def build_jira_payload(event: Dict[str, Any], finding: Dict[str, Any]) -> Dict[str, Any]:
    """Jira 연동용 Payload 생성"""
    sev_label = (
        finding.get("FindingProviderFields", {}).get("Severity", {}).get("Label")
        or finding.get("Severity", {}).get("Label")
        or "N/A"
    )

    finding_arn = (
        finding.get("ProductFields", {}).get("aws/securityhub/FindingId")
        or finding.get("Id")
        or "N/A"
    )

    region = event.get("region") or finding.get("Region") or "ap-northeast-2"
    account = event.get("account") or finding.get("AwsAccountId") or "N/A"
    resources = [r.get("Id", "N/A") for r in finding.get("Resources", [])]

    payload = {
        "_incomingData": {
            "_parsedData": {
                "Source": event.get("source", "aws.securityhub"),
                "Title": finding.get("Title", "No Title"),
                "Severity": {"Label": sev_label},
                "FindingArn": finding_arn,
                "ProductName": finding.get("ProductName", "N/A"),
                "CompanyName": finding.get("CompanyName", "N/A"),
                "Region": region,
                "Account": account,
                "Resources": resources,
                "CreatedAtKST": convert_kst(finding.get("CreatedAt")),
                "UpdatedAtKST": convert_kst(finding.get("UpdatedAt")),
            },
        },
    }
    return payload


def lambda_handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    """Jira 전용 Lambda 핸들러"""
    print("Received raw event:", json.dumps(event)[:2000])

    # SNS 래핑 처리
    if isinstance(event, dict) and "Records" in event:
        try:
            record0 = event["Records"][0]
            if record0.get("EventSource") == "aws:sns":
                sns_message = record0.get("Sns", {}).get("Message", "")
                try:
                    event = json.loads(sns_message)
                    print("Unwrapped SNS message as JSON.")
                except json.JSONDecodeError:
                    event = {"Message": sns_message}
                    print("SNS message is not JSON, wrapped as dict.")
        except Exception as e:
            print("SNS unwrap failed:", str(e))

    detail = event.get("detail", {}) or {}
    findings = detail.get("findings", []) or []

    if not findings:
        print("No findings")
        return {"statusCode": 204, "body": "No findings"}

    sent_jira = 0
    for f in findings:
        # Security Hub 자체 이벤트 제외
        if f.get("ProductName", "").strip() == "Security Hub":
            print(f"Security Hub 이벤트 제외: {f.get('Id', 'N/A')}")
            continue

        try:
            print(f"Sending finding {f.get('Id', 'N/A')} to Jira")
            payload = build_jira_payload(event, f)
            post_to_jira(payload)
            sent_jira += 1
        except Exception as e:
            print("Jira send failed for finding:", f.get("Id", "N/A"), str(e))

    return {"statusCode": 200, "body": f"Jira sent: {sent_jira}"}
