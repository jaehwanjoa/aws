import json
import os
import urllib.request
from datetime import datetime, timedelta
from typing import Dict, Any


def convert_kst(utc_time: str) -> str:
    if not utc_time:
        return "N/A"
    for fmt in ("%Y-%m-%dT%H:%M:%S.%fZ", "%Y-%m-%dT%H:%M:%SZ"):
        try:
            utc = datetime.strptime(utc_time, fmt)
            return (utc + timedelta(hours=9)).strftime("%Y-%m-%d %H:%M:%S")
        except ValueError:
            continue
    return utc_time


def post_to_teams(teams_url: str, message: Dict[str, Any]) -> None:
    req = urllib.request.Request(
        teams_url,
        data=json.dumps(message, ensure_ascii=False).encode("utf-8"),
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=10) as response:
        print("Teams Response:", response.read().decode())


def build_console_url(
    product_name: str,
    region: str,
    detector_id: str,
    finding_id: str,
) -> str:
    product = product_name.lower()

    # GuardDuty
    if product == "guardduty":
        return (
            f"https://{region}.console.aws.amazon.com/guardduty/home"
            f"?region={region}"
            f"#/findings"
            f"?detectorId={detector_id}"
            f"&macros=current"
            f"&search=id%3D{finding_id}"
            f"&fId={finding_id}"
        )

    # Prisma Cloud
    if "prisma" in product:
        return "https://app.sg.prismacloud.io/login"

    # Default: Security Hub
    return (
        f"https://{region}.console.aws.amazon.com/securityhub/home"
        f"?region={region}#/findings"
    )


def lambda_handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    print("===== RAW EVENT =====")
    print(json.dumps(event, ensure_ascii=False))

    # SNS unwrap
    if isinstance(event, dict) and "Records" in event:
        try:
            record = event["Records"][0]
            if record.get("EventSource") == "aws:sns":
                event = json.loads(record["Sns"]["Message"])
                print("===== SNS UNWRAPPED EVENT =====")
                print(json.dumps(event, ensure_ascii=False))
        except Exception as e:
            print("SNS unwrap failed:", str(e))
            return {"statusCode": 400, "body": "SNS unwrap failed"}

    teams_url = os.environ.get("TEAMS_WEBHOOK_URL")
    if not teams_url:
        raise RuntimeError("환경변수 TEAMS_WEBHOOK_URL 이 없습니다.")

    detail_type = event.get("detail-type")
    detail = event.get("detail", {}) or {}
    findings = detail.get("findings", []) or []
    resources = event.get("resources", []) or []

    arn = resources[0].lower() if resources else ""

    # Header
    if detail_type == "Security Hub Findings - Imported":
        header = "🚨 보안 이벤트 자동 알림 (Critical)"
    elif detail_type == "Security Hub Findings - Custom Action":
        header = "🧑‍💻 보안 이벤트 수동 알림"
    else:
        header = "ℹ️ Security Hub 알림"

    sent = 0

    # =====================================================
    # Finding loop
    # =====================================================
    for f in findings:
        print("----- RAW FINDING -----")
        print(json.dumps(f, ensure_ascii=False))

        # 🔴 반드시 먼저 선언 (NameError 방지)
        resource_id = "N/A"
        finding_resources = f.get("Resources", []) or []
        if finding_resources:
            resource_id = finding_resources[0].get("Id", "N/A")

        product_name = f.get("ProductName", "").strip()
        if product_name == "Security Hub":
            continue

        severity_label = f.get("Severity", {}).get("Label", "").upper()

        manual = "action/custom" in arn
        auto = (
            detail_type == "Security Hub Findings - Imported"
            and severity_label == "CRITICAL"
        )

        if not (manual or auto):
            continue

        # Console URL
        finding_id = f.get("Id", "").split("/")[-1]
        region = f.get("Region")
        detector_id = f.get("GeneratorId", "").split("/")[-1]

        console_url = build_console_url(
            product_name=product_name,
            region=region,
            detector_id=detector_id,
            finding_id=finding_id,
        )

        finding_types = f.get("Types", [])
        types_text = "\n".join(f"- {t}" for t in finding_types) if finding_types else "N/A"

        note_text = f.get("Note", {}).get("Text", "N/A")
        recommended_link = f.get("UserDefinedFields", {}).get("Recommanded", "N/A")

        teams_message = {
            "title": f"{header} | {severity_label}",
            "text": (
                f"### 📌 {f.get('Title')}\n"
                f"{f.get('Description','')}\n\n"
                f"**Account**: {f.get('AwsAccountId')}\n"
                f"**Region**: {region}\n"
                f"**Product**: {product_name}\n"
                f"**Severity**: {severity_label}\n"
                f"**Resource (Image URI)**:\n"
                f"`{resource_id}`\n\n"
                f"**First Seen**: {convert_kst(f.get('CreatedAt'))}\n"
                f"**Last Seen**: {convert_kst(f.get('UpdatedAt'))}\n\n"
                f"---\n"
                f"### 🧩 Detection Type\n"
                f"{types_text}\n\n"
                f"---\n"
                f"### 📝 대응 참고 정보\n"
                f"**Note**: {note_text}\n\n"
                f"**📖 Recommended Guide**:\n"
                f"{recommended_link}\n\n"
                f"---\n"
                f"### 🔗 Access Console\n"
                f"{console_url}"
            ),
        }

        post_to_teams(teams_url, teams_message)
        sent += 1

    print(f"Teams messages sent: {sent}")
    return {"statusCode": 200, "body": f"Teams sent: {sent}"}
